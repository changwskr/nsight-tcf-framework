---
name: MG-NAMING_CONVENTION
description: 농협 상호금융 PDMG 명명 규칙. 애플리케이션 컴포넌트 타입↔패키지↔네이밍 매핑, Handler/Facade/Controller/Service/DAO/DTO, MyBatis SQL ID 규칙을 정의한다.
---

# PDMG Naming Convention Guide

## 1. 목적

이 문서는 **현재 `pdmg-service` 소스**(`src/main/java/nhnis/mg`)를 기준으로 한 명명 규칙이다.  
핵심은 **§4 애플리케이션 컴포넌트 ↔ 패키지 ↔ 네이밍** 이다. 컴포넌트 타입이 정해지면 패키지와 이름이 따라온다.  
새 프로그램은 임의 변형보다 본 규칙과 기준 샘플을 따른다.

기준 프로그램 샘플: **mgcoa8888**  
- 조회 `POST /mgcoa8888S0`  
- 삭제 `POST /mgcoa8888D0`  
- 동일 식별번호 통합: `mgcoa8888Handler` + `mgcoa8888Facade` (TCF ON)  
- TCF OFF 호환: `mgcoa8888Controller`

공통 FW: [`pdmg-fw`](../../pdmg-fw/README.md) (`OnlineTransactionController`, `DefaultFilter`, `RequestBody` resolver)

호출 흐름 (TCF ON, `nhnis.fw.tcf.enabled=true`):

```text
DefaultFilter / ServicePreventionInterceptor (pdmg-fw)
  → OnlineTransactionController (pdmg-fw)
    → TcfFacade → TransactionHandler (nhnis.mg.co.a.entry.handler)
      → Facade (@Transactional, nhnis.mg.co.a.application.facade)
        → [BizPrePostAspect] Service (nhnis.mg.co.a.application.service)
          → DAO (nhnis.mg.co.a.persistence.dao)
            → Mapper XML (rdw.mg.co.a/*.xml)
```

호출 흐름 (TCF OFF, 호환):

```text
ServicePreventionInterceptor (pdmg-fw)
  → Controller (nhnis.mg.co.a.application.controller)
    → Service (nhnis.mg.co.a.application.service)
      → DAO → Mapper XML
```

---

## 2. 애플리케이션 분류 체계

서비스 ID·클래스명·**Java 패키지**·Mapper 리소스 폴더에 쓰인다.

### 2.1 대구분

- 애플리케이션 그룹 코드: `MG`
- Boot / 루트 패키지: `nhnis.mg` (`PdmgApplication`, `ServletInitializer`만 둠)
- 메인 클래스: `nhnis.mg.PdmgApplication`

### 2.2 업무구분

| 코드 | 업무구분 |
| ---- | -------- |
| CO | 공통 |
| IC | 통합고객 |
| MS | 미니 상품부 |
| SA | 사업관리 |

### 2.3 세부업무구분

| 코드 | 세부구분 |
| ---- | -------- |
| A | 상담 |
| B | 고객 |

현재 샘플은 모두 `CO` + `A` → 서비스 ID 접두 `mgcoa`, Java 패키지 `nhnis.mg.co.a.*`, Mapper `rdw.mg.co.a/`.

### 2.4 패키지·리소스에 쓰는 표기

업무구분·세부업무구분은 **소문자**로 패키지/폴더 세그먼트에 넣는다.

| 구분 | 표기 | 예시 |
| ---- | ---- | ---- |
| Java 업무 루트 | `nhnis.mg.[업무].[세부]` | `nhnis.mg.co.a` |
| Mapper 리소스 | `rdw.[대구분].[업무].[세부]/` | `rdw.mg.co.a/` |
| 서비스 ID 접두 | `[대구분][업무][세부]` | `mgcoa` |

다른 업무(예: IC + B)를 추가하면 `nhnis.mg.ic.b.*` / `rdw.mg.ic.b/` 아래에 동일 6계층을 둔다.

---

## 3. 서비스 ID 규칙

### 3.1 기본 구조

```text
[대구분 2자][업무구분 2자][세부업무구분 1자][식별번호 4자][구분자 1자][순번 1자]
```

예시:

```text
mgcoa8888S0
```

### 3.2 구성요소

| 구분 | 길이 | 예시 | 설명 |
| ---- | ---: | ---- | ---- |
| 대구분 | 2 | mg | 애플리케이션 그룹 |
| 업무구분 | 2 | co | CO, IC, MS, SA |
| 세부업무구분 | 1 | a | A, B |
| 식별번호 | 4 | 8888 | 화면번호 또는 일반번호 |
| 구분자 | 1 | S/C/U/D/A/R | 조회/등록/수정/삭제/혼합/리포트 |
| 순번 | 1 | 0~9, A~Z | 동일 기능 내 순번 |

### 3.3 구분자

| 구분자 | 의미 |
| ------ | ---- |
| S | 조회 |
| C | 등록 |
| U | 수정 |
| D | 삭제 |
| A | 혼합 |
| R | 리포트 |

### 3.4 예시

```text
조회   : mgcoa8888S0
삭제   : mgcoa8888D0
등록   : mgcoa0000C0
수정   : mgcoa0000U0
혼합   : mgcoa0000A0
리포트 : mgcoa0000R0
```

현재 레포 샘플:

| 프로그램 | API | 설명 |
| -------- | --- | ---- |
| `mgcoa8888` | `POST /mgcoa8888S0`, `POST /mgcoa8888D0` | 이미지로그 조회/삭제 |
| `mgcoa5530` | `POST /mgcoa5530S0` | 마케팅희망고객 목록 |
| `mgcoa9999` | `POST /mgcoa9999S0` | 영업팁 실적 목록 |
| `mgcoa9000` | `POST /mgcoa9000S0`, `C0`, `U0`, `D0` | 거래 파라미터 CRUD |

---

## 4. 애플리케이션 컴포넌트 ↔ 패키지 ↔ 네이밍

PDMG 업무 코드는 **컴포넌트 타입(역할)** 을 먼저 정하고, 그 역할을 **패키지 위치**와 **타입/메서드 이름**에 그대로 투영한다.  
즉 “이 클래스가 어떤 컴포넌트인가?”가 정해지면 패키지와 이름이 자동으로 결정된다.

### 4.1 설계 의도

| 질문 | 답 |
| ---- | -- |
| 왜 패키지를 나누는가? | 의존 방향·트랜잭션·진입 경로를 컴파일/리뷰 시점에 강제하기 위함 |
| 왜 이름이 `mgcoa8888*` 형태인가? | 서비스 ID·화면/프로그램 식별번호와 1:1로 맞추기 위함 |
| 왜 Handler와 Facade를 나누는가? | TCF 라우팅(entry)과 업무 TX 경계(application)를 분리하기 위함 |
| 왜 DTO를 `application` 밖으로 뺐는가? | 입출력 계약은 계층 공통 자산이므로 service와 동급 계층으로 둔다 |

### 4.2 컴포넌트 타입 정의

| 컴포넌트 타입 | 한 줄 정의 | 속한 계층 |
| ------------ | ---------- | -------- |
| Boot | Spring Boot 진입 | `nhnis.mg` (업무축 밖) |
| Handler | TCF ON serviceId 라우팅 | `entry` |
| Aspect | 업무 요청 횡단 선·후처리 / TX-FLOW | `entry` |
| Controller | TCF OFF HTTP 진입 | `application` |
| Facade | DTO 변환 + `@Transactional` + Service 호출 | `application` |
| Service | 업무 절차·DAO 호출 | `application` |
| DTO | 입출력 데이터 계약 | `dto` |
| DAO | MyBatis 영속 계약 | `persistence` |
| Client | 외부 WAS/API 호출 | `client` |
| Config | Spring Bean·DS·보안 조립 | `config` |
| Support | 업무 공통 유틸 | `support` |
| Mapper XML | SQL 리소스 (Java 패키지 밖) | `rdw.mg.[업무].[세부]/` |

### 4.3 마스터 매핑 (타입 → 패키지 → 네이밍)

현재 샘플 업무축 = **`co.a`** (`CO`+`A`).

| 컴포넌트 | 패키지 | 타입/파일 네이밍 | 메서드·기타 네이밍 | 샘플 |
| -------- | ------ | ---------------- | ------------------ | ---- |
| Boot | `nhnis.mg` | `PdmgApplication` | `main` | `PdmgApplication.java` |
| Handler | `nhnis.mg.co.a.entry.handler` | `mgcoa[식별4]Handler` | `serviceIds()`, `handle` | `mgcoa8888Handler` |
| Aspect | `nhnis.mg.co.a.entry.aspect` | 역할 PascalCase | pointcut = 대상 FQCN | `BizPrePostAspect` |
| Controller | `nhnis.mg.co.a.application.controller` | `mgcoa[식별4]Controller` | `@PostMapping("/서비스ID")` | `mgcoa8888Controller` |
| Facade | `nhnis.mg.co.a.application.facade` | `mgcoa[식별4]Facade` | 메서드명 = **서비스 ID** | `mgcoa8888Facade.mgcoa8888S0` |
| Service | `nhnis.mg.co.a.application.service` | `mgcoa[식별4]Service` | 메서드명 = **서비스 ID** | `mgcoa8888Service.mgcoa8888S0` |
| DTO | `nhnis.mg.co.a.dto` | `mgcoa[식별4][S\|C\|U\|D…]DTOin/out/Sub` | 필드 camelCase | `mgcoa8888S0DTOin` |
| DAO | `nhnis.mg.co.a.persistence.dao` | `mgcoa[식별4]DAO` | 메서드명 = **SQL ID** | `mgcoa8888S0_S0` |
| Client | `nhnis.mg.co.a.client` | `*Client` | 연동 API명 | (현재 package-info만) |
| Config | `nhnis.mg.co.a.config` | `*Config` / `*Properties` | Bean camelCase | `RdwDataSourceConfig` |
| Support | `nhnis.mg.co.a.support` | 유틸 PascalCase | static 유틸 | (현재 package-info만) |
| Mapper XML | `resources/rdw.mg.co.a/` | `mgcoa[식별4]-ORA.xml` | `namespace` = DAO FQCN | `mgcoa8888-ORA.xml` |

식별번호 단위 통합 규칙:

```text
서비스 ID들: mgcoa8888S0, mgcoa8888D0
  → Handler / Facade / Controller / Service / DAO 는 모두 mgcoa8888*
  → DTO / SQL ID / URL 만 서비스 ID(구분자 포함)를 쓴다
```

### 4.4 패키지 경로 규칙

```text
nhnis.mg.[업무구분].[세부업무구분].[계층].[세부패키지]
```

| 세그먼트 | 필수 | 예시 | 설명 |
| -------- | ---- | ---- | ---- |
| `nhnis.mg` | 필수 | `nhnis.mg` | 애플리케이션 루트. Boot만 직접 둠 |
| 업무구분 | 필수 | `co` | §2.2 소문자 |
| 세부업무구분 | 필수 | `a` | §2.3 소문자 |
| 계층 | 필수 | `entry` | `entry` / `application` / `dto` / `persistence` / `client` / `config` / `support` |
| 세부패키지 | 선택 | `handler` | 계층 안 컴포넌트 타입 |

실제 트리:

```text
src/main/java/nhnis/mg
├── PdmgApplication.java
├── ServletInitializer.java
└── co/a/                          # 업무=CO, 세부=A
    ├── entry/
    │   ├── aspect/                # Aspect
    │   └── handler/               # Handler (TCF ON)
    ├── application/
    │   ├── controller/            # Controller (TCF OFF)
    │   ├── facade/                # Facade (@Transactional)
    │   └── service/               # Service
    ├── dto/                       # DTO
    ├── persistence/
    │   └── dao/                   # DAO
    ├── client/                    # Client
    ├── config/                    # Config / Properties
    └── support/                   # Support
```

### 4.5 이름이 패키지에서 어떻게 유도되는가

서비스 ID `mgcoa8888S0` 를 예로 들면:

```text
mg | co | a | 8888 | S | 0
 │    │   │    │     │   └─ 순번
 │    │   │    │     └───── 구분자 (조회)
 │    │   │    └─────────── 식별번호 → 클래스 접두 mgcoa8888*
 │    │   └──────────────── 세부 → 패키지 .a. , 리소스 rdw.mg.co.a/
 │    └──────────────────── 업무 → 패키지 .co.
 └───────────────────────── 대구분 → nhnis.mg , rdw.mg
```

| 유도 결과 | 값 |
| --------- | -- |
| Java 업무 루트 | `nhnis.mg.co.a` |
| Mapper 폴더 | `rdw.mg.co.a/` |
| 프로그램 접두 | `mgcoa8888` |
| Handler/Facade/Service/DAO/Controller | `mgcoa8888Handler` … |
| DTO / URL / SQL | `mgcoa8888S0…` / `POST /mgcoa8888S0` / `mgcoa8888S0_S0` |

### 4.6 의존 방향 (패키지로 강제)

```text
entry.handler ──────────────► application.facade
application.controller ─────► application.service   (TCF OFF 호환)
application.facade ─────────► application.service
application.service ────────► persistence.dao , dto
persistence.dao ────────────► (MyBatis XML rdw.mg.co.a)
entry.aspect ───────────────► (pointcut) application.service …
```

금지 의존:

- `entry.handler` → `application.service` / `persistence` 직접 호출
- `application.service` → `entry.*` / `application.controller`
- `dto` → `service` / `dao` 주입
- `persistence.dao` → 업무 판단·HTTP 조립

### 4.7 계층별 원칙 요약

- 업무 코드는 `nhnis.mg` 바로 아래가 아니라 `nhnis.mg.[업무].[세부]` 아래에 둔다.
- Java 패키지 업무축과 Mapper `rdw.mg.[업무].[세부]/` 를 동일하게 맞춘다.
- Aspect pointcut·`@MapperScan` 도 동일 축 FQCN을 쓴다.
- TCF ON 신규 거래는 **Handler + Facade** 를 추가한다. Controller는 TCF OFF 호환용이다.
- REST 스타일(`/api/.../list`, `DtoIn`/`Dao`)·`MG.Xxx.yyy` 점 구분 서비스 ID는 쓰지 않는다.
- `common` / `misc` / `util` 같은 모호한 패키지명은 쓰지 않는다 (`support`는 유틸 전용).

---

## 5. Handler (`entry.handler`)

TCF ON 시 FW `OnlineTransactionController` → `TcfFacade` 가 `TransactionHandler` 구현체를 찾아 호출한다.  
Handler는 **serviceId 라우팅만** 담당하고, 업무·트랜잭션·DTO 변환은 Facade에 둔다.

### 5.1 파일명 / 패키지

```text
패키지 : nhnis.mg.co.a.entry.handler
파일명 : [대구분][업무구분][세부업무구분][식별번호4자리]Handler.java
```

예: `mgcoa8888Handler.java`, `mgcoa5530Handler.java`

클래스명에는 구분자(S/C/U/D…)를 넣지 않는다.  
동일 식별번호의 여러 서비스는 **하나의 Handler**로 통합한다.

```text
mgcoa8888S0 + mgcoa8888D0  →  mgcoa8888Handler
```

### 5.2 애노테이션 / 구현

```java
@Slf4j
@Component
@ConditionalOnProperty(name = "nhnis.fw.tcf.enabled", havingValue = "true")
public class mgcoa8888Handler implements TransactionHandler {
```

| 항목 | 규칙 |
| ---- | ---- |
| 인터페이스 | `nhnis.fw.tcf.core.handler.TransactionHandler` |
| Bean 조건 | `nhnis.fw.tcf.enabled=true` 일 때만 등록 |
| 의존 | 동일 식별번호의 `*Facade` 만 주입 |
| `serviceIds()` | 지원 서비스 ID 목록 반환 |
| `handle(...)` | `context.getServiceId()` 로 Facade 메서드 분기 |

### 5.3 메서드 패턴

```java
@Override
public Collection<String> serviceIds() {
    return List.of(S0, D0);
}

@Override
public Object handle(Object dtoBody, TransactionContext context) throws Exception {
    return switch (context.getServiceId()) {
        case S0 -> facade.mgcoa8888S0(dtoBody);
        case D0 -> facade.mgcoa8888D0(dtoBody);
        default -> throw new ServiceHandlerNotFound(
                "mgcoa8888Handler 미지원 serviceId: " + context.getServiceId());
    };
}
```

금지:

- Handler에서 `@Transactional` 사용
- Handler에서 Service/DAO 직접 호출
- Handler에서 DTO 타입 변환 (`ObjectMapper` 등)

---

## 6. Facade (`application.facade`)

Handler와 Service 사이의 **업무 진입 경계**.  
입력 `Object`(또는 Map) → typed DTO 변환, Spring 트랜잭션, Service 호출을 담당한다.

### 6.1 파일명 / 패키지

```text
패키지 : nhnis.mg.co.a.application.facade
파일명 : [대구분][업무구분][세부업무구분][식별번호4자리]Facade.java
```

예: `mgcoa8888Facade.java`

클래스명에는 구분자(S/C/U/D…)를 넣지 않는다.  
동일 식별번호의 여러 서비스는 **하나의 Facade**로 통합한다.

```text
mgcoa8888S0 + mgcoa8888D0  →  mgcoa8888Facade
```

### 6.2 애노테이션 / 메서드

```java
@Slf4j
@Service
public class mgcoa8888Facade {
```

| 항목 | 규칙 |
| ---- | ---- |
| Spring 스테레오타입 | `@Service` (Facade 역할이지만 Bean은 Service로 등록) |
| 트랜잭션 | 메서드에 `@Transactional(transactionManager = "rdwTransactionManager")` |
| 조회 | `readOnly = true` |
| 메서드명 | **서비스 ID와 동일** (`mgcoa8888S0`, `mgcoa8888D0`) |
| 입력 | `Object dtoBody` → `ObjectMapper.convertValue` → `*DTOin` |
| 출력 | Service가 반환한 `*DTOout` |
| 의존 | 동일 식별번호의 `*Service` + `ObjectMapper` |

### 6.3 메서드 시그니처

```java
@Transactional(transactionManager = "rdwTransactionManager", readOnly = true)
public mgcoa8888S0DTOout mgcoa8888S0(Object dtoBody) throws Exception {
    Object source = dtoBody == null ? Collections.emptyMap() : dtoBody;
    mgcoa8888S0DTOin input = objectMapper.convertValue(source, mgcoa8888S0DTOin.class);
    return service.mgcoa8888S0(input);
}
```

책임 경계:

| 계층 | 담당 | 비담당 |
| ---- | ---- | ------ |
| Handler | serviceId 분기 | TX, DTO 변환, 업무 로직 |
| Facade | TX, DTO 변환, Service 호출 | SQL, HTTP |
| Service | 업무 절차, DAO 호출 | `@Transactional` (Facade에 둠) |

업무 선·후처리(`BizPrePostAspect`)는 **Service 메서드**에 걸린다.  
따라서 `Facade(@Transactional BEGIN) → [BizPre] Service → DAO → [BizPost] → COMMIT` 순서가 된다.

---

## 7. Controller (`application.controller`)

TCF OFF(`nhnis.fw.tcf.enabled=false`) 또는 호환용 HTTP 진입점.  
TCF ON에서는 보통 `@ConditionalOnProperty(..., havingValue = "false", matchIfMissing = true)` 로 비활성한다.  
**신규 거래는 Handler + Facade를 우선**하고, Controller는 필요 시에만 유지한다.

### 7.1 파일명 / 패키지

```text
패키지 : nhnis.mg.co.a.application.controller
파일명 : [대구분][업무구분][세부업무구분][식별번호4자리]Controller.java
```

예: `mgcoa8888Controller.java`

클래스명에는 구분자(S/C/U/D…)를 넣지 않는다.  
동일 식별번호의 여러 서비스는 **하나의 Controller**로 통합한다.

```text
mgcoa8888S0 + mgcoa8888D0  →  mgcoa8888Controller
```

### 7.2 애노테이션

```java
@Slf4j
@RestController
```

- 클래스 레벨 `@RequestMapping` **금지**
- 메서드: `@PostMapping("/서비스ID")`
- 입력: `nhnis.fw.commons.resolver.RequestBody`  
  (요청 JSON의 `dto` 노드 바인딩)

### 7.3 메서드 시그니처

```java
@PostMapping("/mgcoa8888S0")
public mgcoa8888S0DTOout mgcoa8888S0(
        @RequestBody mgcoa8888S0DTOin input
) throws Throwable
```

요청 Body 예: `{"hdr_nhnis":{...},"dto":{...}}`  
local 프로파일에서는 `{"dto":{...}}` 만으로도 가능하다.

---

## 8. Service (`application.service`)

### 8.1 파일명 / 패키지

```text
패키지 : nhnis.mg.co.a.application.service
파일명 : [대구분][업무구분][세부업무구분][식별번호4자리]Service.java
```

예: `mgcoa8888Service.java`

### 8.2 애노테이션 / 메서드

```java
@Service
public class mgcoa8888Service {
    public mgcoa8888S0DTOout mgcoa8888S0(mgcoa8888S0DTOin input) throws Exception { … }
    public mgcoa8888D0DTOout mgcoa8888D0(mgcoa8888D0DTOin input) throws Exception { … }
}
```

- 메서드명 = 서비스 ID
- DAO·DTO는 각각 `persistence.dao`, `dto` 를 import
- `@Transactional`은 Service가 아니라 **Facade**에 둔다 (TCF ON)

---

## 9. DAO (`persistence.dao`)

### 9.1 파일명 / 패키지

```text
패키지 : nhnis.mg.co.a.persistence.dao
파일명 : [대구분][업무구분][세부업무구분][식별번호4자리]DAO.java
```

예: `mgcoa8888DAO.java`

### 9.2 규칙

- `@RDWMapper` (`nhnis.mg.co.a.config.RDWMapper`) 사용
- **DAO 메서드명 = MyBatis SQL ID** (반드시 동일)
- 입력: `Map<String, Object>`
- 출력: `List<Map<String, Object>>` 또는 `int`
- `@MapperScan(basePackages = "nhnis.mg.co.a.persistence.dao")`

### 9.3 메서드명 / SQL ID

```text
[서비스ID]_[DML구분][순번]
[서비스ID]_[DML구분][순번]_count
```

예 (`mgcoa8888DAO`):

```text
mgcoa8888S0_S0
mgcoa8888S0_S0_count
mgcoa8888D0_D0
```

DML 구분: `S` 조회 / `C` 등록 / `U` 수정 / `D` 삭제 / `A` 혼합  
순번: `0~9`, 초과 시 `A~Z`

---

## 10. DTO (`dto`)

### 10.1 파일명

```text
[서비스ID]DTOin.java
[서비스ID]DTOout.java
[서비스ID]DTOSub[순번].java
[서비스ID]DTO*MsgJson.java   (필요 시)
```

패키지: `nhnis.mg.co.a.dto`

예:

```text
mgcoa8888S0DTOin.java
mgcoa8888S0DTOout.java
mgcoa8888S0DTOSub0.java
mgcoa8888D0DTOin.java
mgcoa8888D0DTOout.java
```

### 10.2 기본 요건

- `com.ims.superspring.dto.DataObject` 상속
- Getter/Setter, `clone`, `toString`, `getFieldPropertyMap` 구현
- 필드명: camelCase (`guid`, `pageNo`, `totalCount` …)

### 10.3 Sub DTO

GRID/목록 행용. 메인 out DTO가 Sub 목록을 보유한다.

| 세그먼트 | 예시 |
| -------- | ---- |
| 서비스 ID | `mgcoa8888S0` |
| 고정 | `DTOSub` |
| 순번 | `0` |

예: `mgcoa8888S0DTOSub0`, `mgcoa5530S0DTOSub0`, `mgcoa9999S0DTOSub0`

---

## 11. entry.aspect / config / support / client

### 11.1 entry.aspect (`nhnis.mg.co.a.entry.aspect`)

| 클래스 | 역할 |
| ------ | ---- |
| `BizPrePostAspect` | Service 선/후처리 로그. pointcut: `nhnis.mg.co.a.application.service..*` |

Facade `@Transactional` 안쪽에서 Service 호출 전후에 적용되도록 **application.service** 를 대상으로 한다.

### 11.2 config (`nhnis.mg.co.a.config`)

| 클래스 | 역할 |
| ------ | ---- |
| `RdwDataSourceConfig` | RDW DataSource, MyBatis, `@MapperScan` |
| `RDWMapper` | DAO용 Mapper 애노테이션 |
| `MybatisLogInterceptor` | SQL 로깅 |
| `SecurityConfig` | 무상태 보안 |
| `WebMvcConfig` / `CorsProperties` | MVC·CORS |

### 11.3 support (`nhnis.mg.co.a.support`)

업무 공통 유틸용. 현재 샘플 클래스 없음 → `package-info.java`만 존재.  
유틸 추가 시 이 패키지에 둔다.

### 11.4 client (`nhnis.mg.co.a.client`)

외부 시스템 호출용. 현재 샘플 연동 없음 → `package-info.java`만 존재.  
연동 추가 시 이 패키지에 클라이언트를 둔다.

---

## 12. MyBatis Mapper 리소스

### 12.1 위치

리소스 폴더는 **서비스 ID의 대구분·업무·세부업무**를 점(`.`)으로 연결한다.  
Java 업무 루트(`nhnis.mg.[업무].[세부]`)와 Mapper 폴더의 업무 축을 **동일하게** 맞춘다.

```text
Java  : nhnis.mg.[업무].[세부].persistence.dao
XML   : src/main/resources/rdw.[대구분].[업무].[세부]/
```

현재 샘플:

```text
src/main/resources/rdw.mg.co.a/
  mgcoa8888-ORA.xml
  mgcoa5530-ORA.xml
  mgcoa9999-ORA.xml
  mgcoa9000-ORA.xml
```

스캔 패턴: `classpath*:rdw.*/*.xml`

### 12.2 파일명

```text
[대구분][업무구분][세부업무구분][식별번호4자리]-[DB구분].xml
```

| 코드 | DB |
| ---- | -- |
| ORA | Oracle (로컬 H2 Oracle 모드 포함) |
| MYS | MySQL |
| MSS | MS SQL Server |

### 12.3 namespace

Java DAO FQCN과 일치:

```xml
<mapper namespace="nhnis.mg.co.a.persistence.dao.mgcoa8888DAO">
```

### 12.4 parameterType / resultType

조회·동적 처리 시 `java.util.HashMap` 사용.  
SQL 본문에 SQL ID 주석 포함 (`/* mgcoa8888S0_S0 */`).

---

## 13. SQL 작성 표준

- Oracle SQL 문법 기준 (로컬은 H2 `MODE=Oracle`)
- DB 키워드·Object: 대문자 / 바인딩 변수: 소문자 camelCase
- 테이블 Alias: `T1`, `T2`, `T3` / 컬럼 Alias: `AS` 사용
- Static SQL 원칙, 필요 시 Dynamic SQL
- 부정 비교: `<>`
- 성능: 긍정 조건 우선, `OR` 제한, `UNION ALL` 검토, `LIKE 'AB%'` 등

---

## 14. 변수·주석

### 14.1 Java 변수

- camelCase, 의미 있는 이름 (`guid`, `serviceId`, `totalCount`, `pageNo`)

### 14.2 주석

클래스:

```java
/**
 * 이미지로그 조회/삭제 Controller.
 *
 * @since YYYY.MM.DD
 */
```

날짜 형식: `YYYY.MM.DD`

---

## 15. 코드 생성 워크플로우

1. 대구분 / 업무구분 / 세부업무구분 / 기능(S·C·U·D·A·R) / 식별번호 결정  
2. 서비스 ID 생성 → 예: `mgcoa8888S0`  
3. 업무 패키지 루트 확인 → 예: `nhnis.mg.co.a` / `rdw.mg.co.a`  
4. 파일 생성 (TCF ON 기본):

```text
co/a/entry/handler/mgcoa8888Handler.java
co/a/application/facade/mgcoa8888Facade.java
co/a/application/service/mgcoa8888Service.java
co/a/dto/mgcoa8888S0DTOin.java
co/a/dto/mgcoa8888S0DTOout.java
co/a/dto/mgcoa8888S0DTOSub0.java   (목록 시)
co/a/persistence/dao/mgcoa8888DAO.java
resources/rdw.mg.co.a/mgcoa8888-ORA.xml
```

TCF OFF 호환이 필요하면 `co/a/application/controller/mgcoa8888Controller.java` 도 추가한다.

5. 검증:

- 패키지 FQCN이 `nhnis.mg.[업무].[세부].[계층]...` 인가
- Handler `serviceIds()` · Facade/Service 메서드명 = 서비스 ID
- DAO 메서드명 = SQL ID
- Mapper `namespace` = `nhnis.mg.co.a.persistence.dao.*DAO`
- 리소스 경로 `rdw.mg.co.a/` (Java 업무 축과 동일)
- `@Transactional` 은 Facade, BizPrePost 는 Service

---

## 16. 핵심 체크리스트

| 점검항목 | 기준 |
| -------- | ---- |
| 패키지 | 컴포넌트 타입 → §4 매핑표의 패키지 (`entry.handler` / `application.facade` …) |
| Boot | `PdmgApplication` / `ServletInitializer` 만 `nhnis.mg` |
| 서비스 ID | `mg` + 업무 + 세부 + 식별번호 + 구분자 + 순번 |
| 네이밍 유도 | 서비스 ID → 패키지 축(`co.a`) + 프로그램 접두(`mgcoa8888`) + 컴포넌트 접미사 |
| Handler | `entry.handler`, 식별번호 단위, `TransactionHandler`, serviceId 라우팅만 |
| Facade | `application.facade`, 식별번호 단위, `@Transactional`, 메서드명 = 서비스 ID |
| Controller | `application.controller` (TCF OFF 호환), 클래스 `@RequestMapping` 금지 |
| Service | `application.service`, 메서드명 = 서비스 ID, TX는 Facade |
| DTO | `dto`, `DataObject`, `DTOin`/`DTOout`/`DTOSub` |
| DAO | `persistence.dao`, `@RDWMapper`, 메서드명 = SQL ID |
| Mapper XML | `rdw.mg.[업무].[세부]/[식별]-ORA.xml`, namespace = persistence DAO |
| URL | `POST /[서비스ID]` (TCF: FW `OnlineTransactionController`) |
| Aspect | `entry.aspect.BizPrePostAspect` → `application.service` |
| client / support | 필요 시에만 추가 |
| REST/`MG.Xxx.yyy` | 사용하지 않음 |

---

## 참고

- 본 문서는 `src/main/java/nhnis/mg` 실제 구조(`co/a` 업무 축 포함)에 맞춰 작성한다.
- 공통 FW 클래스명 `PdmgTxLog`, 모듈명 `pdmg-fw` 는 FW 공유 식별자로 유지한다.
- meta `.dto` 파일은 현재 사용하지 않는다.
